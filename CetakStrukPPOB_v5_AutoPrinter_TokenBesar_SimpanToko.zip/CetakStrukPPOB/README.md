# Cetak Struk PPOB V5 — Share Receiver, Token Besar, Printer Auto-Reconnect

## Perbaikan pada versi ini
- Nama toko dan alamat/keterangan toko disimpan di SharedPreferences lokal.
- Printer Bluetooth yang dipilih disimpan berdasarkan alamat perangkat dan dicoba disambungkan kembali saat aplikasi kembali ke foreground.
- Format cetak token PLN menampilkan token besar/tebal dalam beberapa baris agar lebih mudah dibaca pada printer 58 mm.
- Parser mencoba membaca Tarif/Daya dan jumlah kWh jika informasi tersebut ada di teks transaksi yang dibagikan.
- Kolom Tarif/Daya dan kWh dapat diperiksa/diedit manual.

## Build
Build menggunakan Codemagic dan system Gradle, jalankan `gradle assembleDebug` di direktori proyek Android.

## Catatan penting
- Auto-reconnect hanya dapat bekerja jika printer masih dipasangkan dengan Android, Bluetooth aktif, izin Bluetooth diberikan, printer menyala, dan perangkat mendukung koneksi SPP. Android atau printer dapat memutus koneksi; sambung manual tetap tersedia sebagai cadangan.
- Format data Share DANA dapat berubah. Tarif/Daya hanya terisi otomatis jika datanya ditemukan dalam teks atau OCR yang berhasil; selalu periksa data sebelum mencetak.
- Printer thermal dapat berbeda dukungan ESC/POS. Ukuran token besar perlu diuji pada MP-58ECO. Paket ini belum diuji build di Codemagic dan belum diverifikasi pada printer fisik.
- Struk adalah salinan/keterangan transaksi toko, bukan struk resmi yang diterbitkan DANA, PLN, atau bank.
