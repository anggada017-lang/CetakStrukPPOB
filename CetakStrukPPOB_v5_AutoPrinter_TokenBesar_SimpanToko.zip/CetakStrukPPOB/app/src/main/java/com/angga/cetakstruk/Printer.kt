package com.angga.cetakstruk

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.OutputStream
import java.util.UUID

class PrinterManager {
    private val adapter = BluetoothAdapter.getDefaultAdapter()
    private var out: OutputStream? = null
    private var socket: BluetoothSocket? = null
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    @SuppressLint("MissingPermission")
    fun pairedDevices(): List<BluetoothDevice> = adapter?.bondedDevices?.toList()?.sortedBy { it.name ?: it.address } ?: emptyList()

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice): Boolean = try {
        disconnect()
        val candidate = device.createRfcommSocketToServiceRecord(spp)
        adapter?.cancelDiscovery()
        candidate.connect()
        socket = candidate
        out = candidate.outputStream
        true
    } catch (_: Exception) { disconnect(); false }

    @SuppressLint("MissingPermission")
    fun reconnect(address: String): Boolean {
        if (address.isBlank()) return false
        val device = try { adapter?.getRemoteDevice(address) } catch (_: Exception) { null } ?: return false
        return connect(device)
    }

    fun isConnected(): Boolean = try { socket?.isConnected == true && out != null } catch (_: Exception) { false }

    fun print(text: String): Boolean = try {
        val o = out ?: return false
        o.write(byteArrayOf(0x1B, 0x40))
        o.write(byteArrayOf(0x1B, 0x61, 0x00))
        var big = false
        text.lines().forEach { line ->
            when (line) {
                "[[BIG_TOKEN_START]]" -> { big = true; o.write(byteArrayOf(0x1B,0x61,0x01)); o.write(byteArrayOf(0x1B,0x45,0x01)); o.write(byteArrayOf(0x1D,0x21,0x11)) }
                "[[BIG_TOKEN_END]]" -> { big = false; o.write(byteArrayOf(0x1D,0x21,0x00)); o.write(byteArrayOf(0x1B,0x45,0x00)); o.write(byteArrayOf(0x1B,0x61,0x00)) }
                else -> { o.write(line.toByteArray(Charsets.US_ASCII)); o.write(byteArrayOf(0x0A)) }
            }
        }
        if (big) o.write(byteArrayOf(0x1D,0x21,0x00))
        o.write("\n\n\n".toByteArray(Charsets.US_ASCII)); o.flush(); true
    } catch (_: Exception) { disconnect(); false }

    fun disconnect() {
        try { out?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        out = null; socket = null
    }
}
