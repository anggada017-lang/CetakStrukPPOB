package com.angga.cetakstruk

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val printer = PrinterManager()
    private var sharedText by mutableStateOf("")
    private var transaction by mutableStateOf(Transaction())
    private var storeName by mutableStateOf("TOKO ANGGA")
    private var address by mutableStateOf("PPOB & PEMBAYARAN")
    private var template by mutableStateOf("")
    private lateinit var settings: SharedPreferences

    private fun saveStoreSettings(name: String = storeName, details: String = address) {
        if (::settings.isInitialized) {
            settings.edit().putString("store_name", name).putString("store_address", details).apply()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = getSharedPreferences("cetak_struk_settings", MODE_PRIVATE)
        storeName = settings.getString("store_name", "TOKO ANGGA") ?: "TOKO ANGGA"
        address = settings.getString("store_address", "PPOB & PEMBAYARAN") ?: "PPOB & PEMBAYARAN"
        handleIntent(intent)
        setContent { AppUi() }
    }

    override fun onResume() {
        super.onResume()
        if (::settings.isInitialized) {
            val address = settings.getString("printer_address", "").orEmpty()
            val allowed = Build.VERSION.SDK_INT < 31 || ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            if (address.isNotBlank() && allowed && !printer.isConnected()) printer.reconnect(address)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val text = i?.getStringExtra("shared_text").orEmpty()
        if (text.isNotBlank()) {
            sharedText = text
            transaction = Parser.parse(text)
            template = Template.render(transaction, storeName, address)
        }
    }

    private fun requestBtAndThen(action: () -> Unit) {
        val perms = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else emptyArray()
        if (perms.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            action()
        } else {
            btLauncher.launch(perms)
        }
    }

    private val btLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it.values.all { ok -> ok }) { /* user can press printer again */ }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun AppUi() {
        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = androidx.compose.ui.graphics.Color(0xFF5B3CC4),
                secondary = androidx.compose.ui.graphics.Color(0xFF168A79),
                background = androidx.compose.ui.graphics.Color(0xFFF6F5FA),
                surface = androidx.compose.ui.graphics.Color.White
            )
        ) {
            var tab by remember { mutableIntStateOf(0) }
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = { TopAppBar(title = { Column { Text("Cetak Struk PPOB"); Text("Transaksi lebih mudah", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary) } }) },
                bottomBar = {
                    NavigationBar {
                        NavigationBarItem(tab == 0, { tab = 0 }, icon = {}, label = { Text("Transaksi") })
                        NavigationBarItem(tab == 1, { tab = 1 }, icon = {}, label = { Text("Printer") })
                        NavigationBarItem(tab == 2, { tab = 2 }, icon = {}, label = { Text("Template") })
                    }
                }
            ) { pad ->
                when(tab) {
                    0 -> TransactionScreen(Modifier.padding(pad))
                    1 -> PrinterScreen(Modifier.padding(pad))
                    else -> TemplateScreen(Modifier.padding(pad))
                }
            }
        }
    }

    @Composable
    private fun TransactionScreen(modifier: Modifier) {
        Column(
            modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Terima transaksi dari Share", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (sharedText.isBlank()) "Buka DANA atau m-banking, pilih Bagikan, lalu pilih Cetak Struk PPOB. Periksa kembali data sebelum mencetak."
                        else "Data share diterima. Periksa dan edit rincian transaksi di bawah.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            Text("Rincian transaksi", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(transaction.type, { transaction = transaction.copy(type = it) }, label = { Text("Jenis transaksi") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(transaction.customer, { transaction = transaction.copy(customer = it) }, label = { Text("Nama") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(transaction.phone, { transaction = transaction.copy(phone = it) }, label = { Text("Nomor HP/DANA") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(Parser.money(transaction.nominal), { transaction = transaction.copy(nominal = it.filter(Char::isDigit).toLongOrNull() ?: 0) }, label = { Text("Nominal") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(Parser.money(transaction.fee), { transaction = transaction.copy(fee = it.filter(Char::isDigit).toLongOrNull() ?: 0) }, label = { Text("Admin") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(Parser.money(transaction.total), { transaction = transaction.copy(total = it.filter(Char::isDigit).toLongOrNull() ?: 0) }, label = { Text("Total") }, modifier = Modifier.fillMaxWidth())
            if (transaction.token.isNotBlank() || transaction.type.contains("PLN", true) || transaction.type.contains("LISTRIK", true)) {
                OutlinedTextField(transaction.token, { transaction = transaction.copy(token = it) }, label = { Text("Token PLN / Stroom") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(transaction.tariffPower, { transaction = transaction.copy(tariffPower = it) }, label = { Text("Tarif / Daya (mis. R1 / 1.300 VA)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(transaction.kwh, { transaction = transaction.copy(kwh = it) }, label = { Text("Jumlah kWh") }, modifier = Modifier.fillMaxWidth())
            }
            if (transaction.reference.isNotBlank()) OutlinedTextField(transaction.reference, { transaction = transaction.copy(reference = it) }, label = { Text("Referensi") }, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = { template = Template.render(transaction, storeName, address) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Buat Preview Struk") }

            if (template.isNotBlank()) {
                HorizontalDivider()
                Text("Pratinjau struk", style = MaterialTheme.typography.titleMedium)
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Text(template, modifier = Modifier.fillMaxWidth().padding(16.dp), style = MaterialTheme.typography.bodyMedium)
                }
                Button(
                    onClick = { requestBtAndThen { printer.print(template) } },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (printer.isConnected()) "CETAK SEKARANG" else "Hubungkan printer dulu") }
            }
        }
    }

    @Composable
    private fun PrinterScreen(modifier: Modifier) {
        var devices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
        var msg by remember { mutableStateOf("Belum terhubung") }
        Column(modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Printer Bluetooth", style = MaterialTheme.typography.titleLarge)
                Text("Pilih printer satu kali. Aplikasi akan menyimpan pilihan dan mencoba menyambungkan kembali saat dibuka, selama Bluetooth aktif dan izin diberikan.", style = MaterialTheme.typography.bodyMedium)
                Text("Printer tersimpan: ${settings.getString("printer_name", "Belum dipilih")}", style = MaterialTheme.typography.bodySmall)
                Text(if (printer.isConnected()) "Status: Terhubung" else "Status: Belum terhubung", color = if (printer.isConnected()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            } }
            Button(onClick = {
                requestBtAndThen {
                    devices = printer.pairedDevices()
                    msg = "Pilih printer yang sudah dipairing di Android."
                }
            }) { Text("Tampilkan Printer Pairing") }
            Text(msg)
            devices.forEach { d ->
                OutlinedButton(onClick = {
                    requestBtAndThen {
                        msg = if (printer.connect(d)) { settings.edit().putString("printer_address", d.address).putString("printer_name", d.name ?: "Bluetooth printer").apply(); "Terhubung: ${d.name}. Pilihan printer disimpan." } else "Gagal terhubung. Pastikan printer menyala dan sudah dipasangkan di pengaturan Bluetooth HP."
                    }
                }, modifier = Modifier.fillMaxWidth()) {
                    Text("${d.name ?: "Bluetooth"}\n${d.address}")
                }
            }
            Button(onClick = { if (printer.print("TEST PRINT\nMP-58ECO\nCetak Struk PPOB\n")) msg = "Test print dikirim." else msg = "Belum terhubung." }) {
                Text("Test Print")
            }
        }
    }

    @Composable
    private fun TemplateScreen(modifier: Modifier) {
        Column(modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Identitas toko", style = MaterialTheme.typography.titleLarge)
                    Text("Pengaturan ini tersimpan di HP dan tetap ada saat Anda pindah ke aplikasi lain atau membuka Cetak Struk kembali.", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = storeName,
                        onValueChange = { storeName = it; saveStoreSettings(name = it) },
                        label = { Text("Nama toko") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it; saveStoreSettings(details = it) },
                        label = { Text("Alamat / keterangan toko") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                    Button(onClick = { saveStoreSettings(); template = Template.render(transaction, storeName, address) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Simpan pengaturan toko")
                    }
                    Text("Pengaturan akan ikut digunakan pada pratinjau struk berikutnya.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
