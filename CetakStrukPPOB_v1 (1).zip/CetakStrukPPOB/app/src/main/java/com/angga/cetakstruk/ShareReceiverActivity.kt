package com.angga.cetakstruk

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class ShareReceiverActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val intent = intent
        val type = intent.type ?: ""
        if (type.startsWith("text/")) {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            openMain(text)
        } else if (type.startsWith("image/")) {
            val uri = intent.getParcelableExtra<android.net.Uri>(Intent.EXTRA_STREAM)
            if (uri == null) {
                openMain("")
            } else {
                lifecycleScope.launch {
                    val ocr = try { Ocr.recognize(this@ShareReceiverActivity, uri) } catch (_: Exception) { "" }
                    openMain(ocr)
                }
            }
        } else {
            openMain("")
        }
    }

    private fun openMain(text: String) {
        val i = Intent(this, MainActivity::class.java)
            .putExtra("shared_text", text)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(i)
        finish()
    }
}
