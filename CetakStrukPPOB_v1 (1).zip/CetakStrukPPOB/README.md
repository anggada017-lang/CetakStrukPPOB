# Cetak Struk PPOB — Android v1

Prototype Android untuk:
- menerima Share teks dari DANA/BCA/m-banking;
- menerima Share gambar dan OCR dengan ML Kit;
- mengenali contoh DANA Token PLN, DANA Kirim Uang, dan BCA m-Transfer;
- preview/edit field transaksi;
- koneksi Bluetooth Classic SPP ke printer thermal seperti MP-58ECO;
- cetak ESC/POS sederhana;
- pengaturan nama toko.

## Cara menjalankan
1. Buka folder ini di Android Studio terbaru.
2. Tunggu Gradle Sync.
3. Hubungkan HP Android atau emulator (Bluetooth hanya bisa diuji di HP).
4. Build & Run.
5. Pair MP-58ECO dari pengaturan Bluetooth Android.
6. Buka aplikasi > Printer > Tampilkan Printer Pairing > pilih printer > Test Print.
7. Dari DANA/BCA pilih Bagikan > Cetak Struk PPOB.

## Catatan
- Parser v1 dibuat berdasarkan tiga contoh transaksi yang diberikan.
- Format Share setiap aplikasi dapat berbeda; parser perlu ditambah untuk format baru.
- OCR membutuhkan unduhan dependency ML Kit saat Gradle build.
- UTF-8 pada sebagian printer thermal murah dapat bermasalah untuk karakter tertentu. Jika hasil cetak aneh, tahap berikutnya adalah menambahkan codepage ESC/POS yang sesuai dengan firmware MP-58ECO.
- Sebelum dipakai operasional, lakukan uji pada printer dan aplikasi sumber transaksi yang sebenarnya.

## Fitur lanjutan yang disarankan
- editor template visual per jenis transaksi;
- logo/QR/barcode;
- riwayat SQLite/Room;
- auto-print setelah Share;
- parser GoPay/OVO/ShopeePay/BRI/BNI/Mandiri;
- pilihan cetak 58 mm/80 mm;
- pemotongan kertas/feed yang sesuai firmware printer;
- backup/restore template.
